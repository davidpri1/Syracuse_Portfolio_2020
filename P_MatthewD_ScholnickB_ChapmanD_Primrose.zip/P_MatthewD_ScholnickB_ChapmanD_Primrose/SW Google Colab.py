# -*- coding: utf-8 -*-
"""
Created on Sat May 30 17:25:43 2020


"""


import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
from PIL import Image
# Input data files are available in the "../input/" directory.
# For example, running this (by clicking run or pressing Shift+Enter) will list the files in the input directory
import re
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords

import nltk as nlp

data = pd.read_csv('C:/Users/BeauChapman/OneDrive - DNI/School/Text Mining/starwarsmovies_edit_4.csv')

#episodeIV = pd.read_csv('Star Wars Corpus/SW_EpisodeIV.txt', delim_whitespace=True, names=["index","character","dialogue"] ,header = None)
#episodeV = pd.read_csv('Star Wars Corpus/SW_EpisodeV.txt', delim_whitespace=True, names=["index","character","dialogue"] ,header = None)
#episodeVI = pd.read_csv('Star Wars Corpus/SW_EpisodeVI.txt',delim_whitespace=True, names=["index","character","dialogue"] ,header = None)

#episodeIV["episode"]="A New Hope"
#episodeV["episode"]="The Empire Strikes Back"
#episodeVI["episode"]="Return of The Jedi"
#Phantom["episode"]="Episode I – The Phantom Menace"
#sith["episode"]="Episode III – Revenge of the Sith"
#force_awakens["episode"]="Episode VII – The Force Awakens"
#thelastjedi["episode"]="Episode VIII – The Last Jedi"
#rise["episode"]="Episode IX – The Rise of Skywalker"


#data=pd.concat([
    #Phantom
     #           ,sith
                episodeIV
                ,episodeV
                ,episodeVI
      #          ,force_awakens
       #         ,thelastjedi
        #        ,rise]
 #              ],axis=0
  #             ,ignore_index=True)


data['ccharacter'] = data.character.str.replace(r'[^a-zA-Z0-9]\s?',r'',regex=True)
data.columns = data.columns.str.strip()




description_list=[]

for description in data.dialogue:
   description=re.sub("[^a-zA-Z]", " ", description)
   description=description.lower()
   description=nltk.word_tokenize(description)
   description=[word for word in description if not word in set(stopwords.words("english"))]
   lemma=nlp.WordNetLemmatizer()
   description=[lemma.lemmatize(word) for word in description]
   description=" ".join(description)
   description_list.append(description)
   
# Dropping unneeded columns
data = data.drop(['Unnamed: 0', 'episode', 'ccharacter'],
                 axis=1)



pd.DataFrame(data.character.value_counts()).iloc[:70]

# Turn top 50 characters into a dataframe for corpus creation
LUKE=data[data.character=="LUKE"]
YODA=data[data.character=="YODA"]
HAN=data[data.character=="HAN"]
VADER=data[data.character=="VADER"]
C3PO=data[data.character=="C3PO"]
OBIWAN=data[data.character=="OBI-WAN"]
FINN=data[data.character=="FINN"]
ANAKIN=data[data.character=="ANAKIN"]
REY=data[data.character=="REY"]
POE=data[data.character=="POE"]
LEIA=data[data.character=="LEIA"]
QUIGON=data[data.character=="QUI-GON"]
PALPATINE=data[data.character=="PALPATINE"]
PADME=data[data.character=="PADME"]
LANDO=data[data.character=="LANDO"]
KYLOREN=data[data.character=="KYLO REN"]
JARJAR=data[data.character=="JAR JAR"]
ROSE=data[data.character=="ROSE"]
NUTE=data[data.character=="NUTE"]
BAILORGANA=data[data.character=="BAIL ORGANA"]
EMPEROR=data[data.character=="EMPEROR"]
REDLEADER=data[data.character=="RED LEADER"]
CAPTAINPANAKA=data[data.character=="CAPTAIN PANAKA"]
BIGGS=data[data.character=="BIGGS"]
ARMITAGEHUX=data[data.character=="ARMITAGE HUX"]
SHMI=data[data.character=="SHMI"]
STORMTROOPER=data[data.character=="STORMTROOPER"]
JANNAH=data[data.character=="JANNAH"]
WATTO=data[data.character=="WATTO"]
ZORII=data[data.character=="ZORII"]
TARKIN=data[data.character=="TARKIN"]
JABBA=data[data.character=="JABBA"]
OWEN=data[data.character=="OWEN"]
CREATURE=data[data.character=="CREATURE"]
MAZ=data[data.character=="MAZ"]
DJ=data[data.character=="DJ"]
GENERALGRIEVOUS=data[data.character=="GENERAL GRIEVOUS"]
TROOPER=data[data.character=="TROOPER"]
MACEWINDU=data[data.character=="MACE WINDU"]
DARTHSIDIOUS=data[data.character=="DARTH SIDIOUS"]
B=data[data.character=="B"]
BOSSNASS=data[data.character=="BOSS NASS"]
SNAP=data[data.character=="SNAP"]
ENRICPRYDE=data[data.character=="ENRIC PRYDE"]
MACE=data[data.character=="MACE"]
FN2187=data[data.character=="FN-2187"]
OFFICER=data[data.character=="OFFICER"]
AMILYNHOLDO=data[data.character=="AMILYN HOLDO"]
FODEBEED=data[data.character=="FODE/BEED"]
SNOKE=data[data.character=="SNOKE"]


# INspecting created DFs
type(LUKE)
LUKE.head()
LUKE.columns

os.chdir("C:\Users\BeauChapman\OneDrive - DNI\School\Text Mining\Star Wars Corpus 2")

# Dropping unneeded columns and creating text files for corpus
LUKE = LUKE.drop(['character'], axis=1)
LUKE.to_csv('LUKE.txt')

YODA = YODA.drop(['character'], axis=1)
YODA.to_csv('YODA.txt')

HAN = HAN.drop(['character'], axis=1)
HAN.to_csv('HAN.txt')

VADER = VADER.drop(['character'], axis=1)
VADER.to_csv('VADER.txt')

C3PO= C3PO.drop(['character'], axis=1)
C3PO.to_csv('C3PO.txt')

OBIWAN = OBIWAN.drop(['character'], axis=1)
OBIWAN.to_csv('OBIWAN.txt')

FINN = FINN.drop(['character'], axis=1)
FINN.to_csv('FINN.txt')

ANAKIN = ANAKIN.drop(['character'], axis=1)
ANAKIN.to_csv('ANAKIN.txt')

REY = REY.drop(['character'], axis=1)
REY.to_csv('REY.txt')

POE = POE.drop(['character'], axis=1)
POE.to_csv('POE.txt')

LEIA = LEIA.drop(['character'], axis=1)
LEIA.to_csv('LEIA.txt')

QUIGON = QUIGON.drop(['character'], axis=1)
QUIGON.to_csv('QUIGON.txt')

PALPATINE = PALPATINE.drop(['character'], axis=1)
PALPATINE.to_csv('PALPATINE.txt')

PADME = PADME.drop(['character'], axis=1)
PADME.to_csv('PADME.txt')

LANDO = LANDO.drop(['character'], axis=1)
LANDO.to_csv('LANDO.txt')

KYLOREN = KYLOREN.drop(['character'], axis=1)
KYLOREN.to_csv('KYLOREN.txt')

JARJAR = JARJAR.drop(['character'], axis=1)
JARJAR.to_csv('JARJAR.txt')

ROSE = ROSE.drop(['character'], axis=1)
ROSE.to_csv('ROSE.txt')

NUTE = NUTE.drop(['character'], axis=1)
NUTE.to_csv('NUTE.txt')

BAILORGANA = BAILORGANA.drop(['character'], axis=1)
BAILORGANA.to_csv('BAILORGANA.txt')

EMPEROR = EMPEROR.drop(['character'], axis=1)
EMPEROR.to_csv('EMPEROR.txt')

REDLEADER = REDLEADER.drop(['character'], axis=1)
REDLEADER.to_csv('REDLEADER.txt')

CAPTAINPANAKA = CAPTAINPANAKA.drop(['character'], axis=1)
CAPTAINPANAKA.to_csv('CAPTAINPANAKA.txt')

BIGGS = BIGGS.drop(['character'], axis=1)
BIGGS.to_csv('BIGGS.txt')

ARMITAGEHUX = ARMITAGEHUX.drop(['character'], axis=1)
ARMITAGEHUX.to_csv('ARMITAGEHUX.txt')

SHMI = SHMI.drop(['character'], axis=1)
SHMI.to_csv('SHMI.txt')

STORMTROOPER = STORMTROOPER.drop(['character'], axis=1)
STORMTROOPER.to_csv('STORMTROOPER.txt')

JANNAH = JANNAH.drop(['character'], axis=1)
JANNAH.to_csv('JANNAH.txt')

WATTO = WATTO.drop(['character'], axis=1)
WATTO.to_csv('WATTO.txt')

ZORII = ZORII.drop(['character'], axis=1)
ZORII.to_csv('ZORII.txt')

TARKIN = TARKIN.drop(['character'], axis=1)
TARKIN.to_csv('TARKIN.txt')

JABBA = JABBA.drop(['character'], axis=1)
JABBA.to_csv('JABBA.txt')

OWEN = OWEN.drop(['character'], axis=1)
OWEN.to_csv('OWEN.txt')

CREATURE= CREATURE.drop(['character'], axis=1)
CREATURE.to_csv('CREATURE.txt')

MAZ = MAZ.drop(['character'], axis=1)
MAZ.to_csv('MAZ.txt')

DJ = DJ.drop(['character'], axis=1)
DJ.to_csv('DJ.txt')

GENERALGRIEVOUS = GENERALGRIEVOUS.drop(['character'], axis=1)
GENERALGRIEVOUS.to_csv('GENERALGRIEVOUS.txt')

TROOPER = TROOPER.drop(['character'], axis=1)
TROOPER.to_csv('TROOPER.txt')

MACEWINDU = MACEWINDU.drop(['character'], axis=1)
MACEWINDU.to_csv('MACEWINDU.txt')

DARTHSIDIOUS = DARTHSIDIOUS.drop(['character'], axis=1)
DARTHSIDIOUS.to_csv('DARTHSIDIOUS.txt')

B = B.drop(['character'], axis=1)
B.to_csv('B.txt')

BOSSNASS = BOSSNASS.drop(['character'], axis=1)
BOSSNASS.to_csv('BOSSNASS.txt')

SNAP = SNAP.drop(['character'], axis=1)
SNAP.to_csv('SNAP.txt')

ENRICPRYDE = ENRICPRYDE.drop(['character'], axis=1)
ENRICPRYDE.to_csv('ENRICPRYDE.txt')

MACE = MACE.drop(['character'], axis=1)
MACE.to_csv('MACE.txt')

FN2187 = FN2187.drop(['character'], axis=1)
FN2187.to_csv('FN2187.txt')

OFFICER = OFFICER.drop(['character'], axis=1)
OFFICER.to_csv('OFFICER.txt')

AMILYNHOLDO = AMILYNHOLDO.drop(['character'], axis=1)
AMILYNHOLDO.to_csv('AMILYNHOLDO.txt')

FODEBEED = FODEBEED.drop(['character'], axis=1)
FODEBEED.to_csv('FODEBEED.txt')

SNOKE = SNOKE.drop(['character'], axis=1)
SNOKE.to_csv('SNOKE.txt')


# Setting up path to corpus
path="C:/Users/BeauChapman/OneDrive - DNI/School/Text Mining/Star Wars Corpus 2"
print("calling os...")
FileNameList=os.listdir(path)
## check the TYPE
print(type(FileNameList))
print(FileNameList)

## Notice that I defined path above.
ListOfCompleteFilePaths=[]
ListOfJustFileNames=[]

for name in os.listdir(path):
    #C:\\Users\\profa\\Documents\\Python Scripts\\TextMining\\Week2_3\\CorpusHikeDog_Small\\Dog1.txt
    print(path+ "\\" + name)
    next=path+ "\\" + name
    
    nextnameL=name.split(".")   ##If name is Dog1.txt is splits it into Dog1   and txt
    nextname=nextnameL[0]   ## This gives me: Dog1
    
    ListOfCompleteFilePaths.append(next)
    ListOfJustFileNames.append(nextname)

#print("DONE...")
print("full list...")
print(ListOfCompleteFilePaths)
print(ListOfJustFileNames)


#add more stopwords
stopwords = nltk.corpus.stopwords.words('english')
#newwords = ('anakin', 'artoo', 'chancellor', 'chewie', 'emperor', 'finn', 
           # 'han', 'kenobi', 'leia', 'luke', 'obi', 'poe', 'rey', 'skywalker', 
            #'solo', 'vader'
                             )
#stopwords = stopwords.append(newwords)

# Setting up CountVec with features of 1000 for now
MyVect3=CountVectorizer(input='filename',
                        stop_words=stopwords,
                        max_features=2000
                        )
## NOw I can vectorize using my list of complete paths to my files
X_DH=MyVect3.fit_transform(ListOfCompleteFilePaths)

## Let's get the feature names which ARE the words
ColumnNames3=MyVect3.get_feature_names()
#print(ColumnNames3)

## OK good - but we want a document topic model A DTM (matrix of counts)
CorpusDF_StarWars=pd.DataFrame(X_DH.toarray(),columns=ColumnNames3)
print(CorpusDF_StarWars)

## Now update the row names
MyDict={}
for i in range(0, len(ListOfJustFileNames)):
    MyDict[i] = ListOfJustFileNames[i]

print("MY DICT:", MyDict)
        
CorpusDF_StarWars=CorpusDF_StarWars.rename(MyDict, axis="index")
print(CorpusDF_StarWars)
## That's pretty!
## WHat can you do from here? Anything!
## First - see what data object type you actually have


print(type(CorpusDF_StarWars))


## We have what we expected - a data frame.

# Convert DataFrame to matrix
MyMatrixSW = CorpusDF_StarWars.values
## Check it

print(type(MyMatrixSW))
print(MyMatrixSW)


##############################################################################
###Did not use TFIDF but here is the code if needed###########################
##############################################################################
MyVect_TF=TfidfVectorizer(input='filename',
                        stop_words='english',
                        max_features=100
                        )
## NOw I can vectorize using my list of complete paths to my files
TF_DH=MyVect_TF.fit_transform(ListOfCompleteFilePaths)

## NOw - what do we have?
##print(X_DH)

## Hmm - that's not quite what we want...
## Let's get the feature names which ARE the words
ColumnNamesTF=MyVect_TF.get_feature_names()
#print(ColumnNames3)

## OK good - but we want a document topic model A DTM (matrix of counts)
CorpusDF_DogHike_TF=pd.DataFrame(TF_DH.toarray(),columns=ColumnNamesTF)
print(CorpusDF_DogHike_TF)

## Now update the row names
MyDict={}
for i in range(0, len(ListOfJustFileNames)):
    MyDict[i] = ListOfJustFileNames[i]

print("MY DICT:", MyDict)
        
CorpusDF_DogHike_TF=CorpusDF_DogHike_TF.rename(MyDict, axis="index")
print(CorpusDF_DogHike_TF)
## That's pretty!
## WHat can you do from here? Anything!
## First - see what data object type you actually have


print(type(CorpusDF_DogHike_TF))


## We have what we expected - a data frame.

# Convert DataFrame to matrix
MyMatrixDogHike = CorpusDF_DogHike.values
## Check it

print(type(MyMatrixDogHike))
print(MyMatrixDogHike)
##############################################################################
##############################################################################
##############################################################################

##############################################################################
#k means clustering###########################################################
##############################################################################
# Using sklearn
## you will need
## from sklearn.cluster import KMeans
## import numpy as np
# Starting clusters with k at 4 but we will see after that
kmeans_object = sklearn.cluster.KMeans(n_clusters=15, n_init=10)
#print(kmeans_object)
kmeans_object.fit(MyMatrixSW)
y_kmeans = kmeans_object.predict(MyMatrixSW)

#kmeans_object.fit_predict
# Get cluster assignment labels
labels = kmeans_object.labels_
#print(labels)
# Format results as a DataFrame
Myresults = pd.DataFrame([CorpusDF_StarWars.index,labels]).T
print(Myresults)

### Hmmm -  these are not great results
## This is because my dataset if not clean
## I still have stopwords
## I still have useless or small words < size 3

## Let's clean it up....
## Let's start with this: 



plt.scatter(MyMatrixSW[:, 0], MyMatrixSW[:, 1], c=y_kmeans, s=50, cmap='viridis')

centers = kmeans.cluster_centers_
plt.scatter(centers[:, 0], centers[:, 1], c='black', s=200, alpha=0.5);



order_centriods = kmeans_object.cluster_centers_.argsort() [:, ::-1]
terms = MyVect3.get_feature_names()

print(order_centriods)
print(terms)


###############################################
###
###         From here and down - I am doing
###         things by hand so you can see how
###         to do things without packages
###
#####################################################
## Let's remove our own stopwords that WE create

## Let's also remove all words of size 2 or smaller
## Finally, without using a stem package - 
## Let's combine columns with dog, dogs
## and with hike, hikes, hiking

## We need to "build" this in steps.
## First, I know that I need to be able to access
## the columns...

for name in ColumnNames3:
    print(name)

## OK - that works...
## Now access the column by name

for name in ColumnNames3:
    print(CorpusDF_DogHike[name])

## OK - can we "add" columns??
## lets test some things first
    
 
name1="hikes"
name2="hike"
if(name1 == name2):
    print("TRUE")
else:
    print("FALSE")

name1=name1.rstrip("s")
print(name1)
if(name1 == name2):
    print("TRUE")
else:
    print("FALSE")
    
    #############################

## RE: https://docs.python.org/2.0/lib/module-string.html
## Now - let's put these ideas together
    ## note that strip() takes off the front
    ## rstrip() takes off the rear
## BEFORE

   

############################################
### Had a very odd 3-hour issue
### My code would not remove or see "and"
### Then I noticed that my for loop was
### "skipping" items that I thought were there
### WHy is this true?
### SOlution - always make a copy
### do not "do work" as you iterate - it
### messes up the index behind the scenes

###########################################
print("The initial column names:\n", ColumnNames3)
print(type(ColumnNames3))  ## This is a list
MyStops=["also", "and", "are", "you", "of", "let", "not", "the", "for", "why", "there", "one", "which"]   

 ## MAKE COPIES!
CleanDF=CorpusDF_DogHike
print("START\n",CleanDF)
## Build a new columns list
ColNames=[]

for name in ColumnNames3:
    #print("FFFFFFFF",name)
    if ((name in MyStops) or (len(name)<3)):
        #print("Dropping: ", name)
        CleanDF=CleanDF.drop([name], axis=1)
        #print(CleanDF)
    else:
        ## I MUST add these new ColNames
        ColNames.append(name)
        

#print("END\n",CleanDF)             
print("The ending column names:\n", ColNames)


for name1 in ColNames:
    for name2 in ColNames:
        if(name1 == name2):
            print("skip")
        elif(name1.rstrip("e") in name2):  ## this is good for plurals
            ## like dog and dogs, but not for hike and hiking
            ## so I will strip an "e" if there is one...
            print("combining: ", name1, name2)
            print(CorpusDF_DogHike[name1])
            print(CorpusDF_DogHike[name2])
            print(CorpusDF_DogHike[name1] + CorpusDF_DogHike[name2])
            
            ## Think about how to test this!
            ## at first, you can do this:
            ## NEW=name1+name2
            ## CleanDF[NEW]=CleanDF[name1] + CleanDF[name2]
            ## Then, before dropping any columns - print
            ## the columns and their sum to check it. 
            
            CleanDF[name1] = CleanDF[name1] + CleanDF[name2]
            
            ### Later and once everything is tested - you
            ## will include this next line of code. 
            ## While I tested everyting, I had this commented out
            ###   "******
            CleanDF=CleanDF.drop([name2], axis=1)
        
print(CleanDF.columns.values)

## Confirm that your column summing is working!

print(CleanDF["dog"])
#print(CleanDF["dogs"])
#print(CleanDF["dogdogs"])  ## this should be the sum

## AFTER
print(CleanDF)

## NOW - let's try k means again....
############################## k means ########################

# Convert DataFrame to matrix
MyMatrixClean = CleanDF.values
## Check it
print(type(MyMatrixClean))
print(MyMatrixClean)

# Using sklearn
## you will need
## from sklearn.cluster import KMeans
## import numpy as np
kmeans_object2 = sklearn.cluster.KMeans(n_clusters=3)
#print(kmeans_object)
kmeans_object2.fit(MyMatrixClean)
# Get cluster assignment labels
labels2 = kmeans_object2.labels_
print("k-means with k = 3\n", labels2)
# Format results as a DataFrame
Myresults2 = pd.DataFrame([CleanDF.index,labels2]).T
print("k means RESULTS\n", Myresults2)

################# k means with k = 2 #####################


# Using sklearn
## you will need
## from sklearn.cluster import KMeans
## import numpy as np
kmeans_object3 = sklearn.cluster.KMeans(n_clusters=2)
#print(kmeans_object)
kmeans_object3.fit(MyMatrixClean)
# Get cluster assignment labels
labels3 = kmeans_object3.labels_
print("K means with k = 2\n", labels3)
# Format results as a DataFrame
Myresults3 = pd.DataFrame([CleanDF.index,labels3]).T
print("k means RESULTS\n", Myresults3)





































character=pd.concat([luke, yoda, han, vader])
character.head()
luke.head()
# Initialize
vectorizer = CountVectorizer()
doc_vec = vectorizer.fit_transform(character)
 
# Create dataFrame
df2 = pd.DataFrame(doc_vec.toarray().transpose(),
                   index=vectorizer.get_feature_names())

df2.head()


import sklearn
from sklearn.cluster import KMeans
import numpy as np

myKmeans = sklearn.cluster.KMeans(n_clusters=2)

# Fit the Kmeans alghorithm
myKmeans.fit(character)
# Define Kmeans labels
labels = myKmeans.labels_
print(labels)
# Ge results of clustering
Myresults = pd.DataFrame([CorpusSW.index,labels]).T
print(Myresults)
# print corpus
print(CorpusSW)
